import React from 'react';

const FavModal = () => {
    return (
        <div className="fav-btn-modal">
            <p className="fav-btn-modal__desc">
                Добавлено в <span>Избранное</span>
            </p>
        </div>
    );
};

export default FavModal;
