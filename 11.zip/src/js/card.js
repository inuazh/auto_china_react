import reactApp from './reactApp.js';
reactApp();



// Button favorite
import btnFav from './modules/btn-fav.js';
btnFav();

// Мобильная навигация
import mobileNav2 from './modules/mobile-nav2.js';
mobileNav2();

// Card Slider Mobile
import cardSliderMobile from './modules/card-slider-mobile.js';
cardSliderMobile();

// Card Slider img - выдает ошибку по наведению на каждый слайд (нужно отрефакторить)
import changeImage from './modules/card-slider-img.js';
changeImage();




